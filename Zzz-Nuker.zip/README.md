# Zzz Nuker
A discord Nuker Written In Python By Aizer . Just Like "Lithium Nuker" . Not A Skid Of Lithum Nuker .

# Dev
- AIZER 
- mohit.4sure#0
- https://discord.gg/ntop

# Open Source Nuker 

# NOTE
- Don't Say This Is Skid Of Lithum Nuker . 
- Lithium Nuker Is in CSharp 
- Zzz in Python 

# Setup

- install all modules 
- run "Zzz.py"
- Put Token In Input 
- Put Server Id (Guild Id)
- Use Only In Bot Not In Self Bot 

# Important 
- must Give Credits 
- enjoy 
- ok bye 